function y = KE88_dibujo(x)
% Vista 3D en vivo del KE88 durante la simulacion
persistent ax b1 b2 pr nz tr X t0
y = 0; x = x(:);
if isempty(ax) || ~isgraphics(ax)
    f = figure(99); clf(f); set(f,'Name','KE88 en vivo','Color','w');
    ax = axes('Parent',f); hold(ax,'on'); grid(ax,'on'); view(ax,45,20);
    [gx,gy] = meshgrid(-3:1:3);
    surf(ax,gx,gy,0*gx,'FaceColor',[0.9 0.95 0.9],'EdgeColor',[0.8 0.85 0.8]);
    b1 = plot3(ax,nan,nan,nan,'k-','LineWidth',3);
    b2 = plot3(ax,nan,nan,nan,'k-','LineWidth',3);
    pr = plot3(ax,nan,nan,nan,'o','MarkerSize',8,'MarkerFaceColor',[0.2 0.6 0.3]);
    nz = plot3(ax,nan,nan,nan,'r.','MarkerSize',18);
    tr = plot3(ax,nan,nan,nan,'b-');
    xlabel(ax,'x [m]'); ylabel(ax,'y [m]'); zlabel(ax,'z [m]');
    X = []; t0 = tic;
end
if toc(t0) < 0.08, return; end
t0 = tic;
pos = x(1:3); ph = x(7); th = x(8); ps = x(9);
R = [cos(ps)*cos(th), cos(ps)*sin(th)*sin(ph)-sin(ps)*cos(ph), cos(ps)*sin(th)*cos(ph)+sin(ps)*sin(ph);
     sin(ps)*cos(th), sin(ps)*sin(th)*sin(ph)+cos(ps)*cos(ph), sin(ps)*sin(th)*cos(ph)-cos(ps)*sin(ph);
     -sin(th), cos(th)*sin(ph), cos(th)*cos(ph)];
d = 0.075;
p1 = pos+R*[d;d;0]; p2 = pos+R*[d;-d;0]; p3 = pos+R*[-d;-d;0]; p4 = pos+R*[-d;d;0];
pn = pos+R*[1.5*d;0;0];
set(b1,'XData',[p1(1) p3(1)],'YData',[p1(2) p3(2)],'ZData',[p1(3) p3(3)]);
set(b2,'XData',[p2(1) p4(1)],'YData',[p2(2) p4(2)],'ZData',[p2(3) p4(3)]);
set(pr,'XData',[p1(1) p2(1) p3(1) p4(1)],'YData',[p1(2) p2(2) p3(2) p4(2)],'ZData',[p1(3) p2(3) p3(3) p4(3)]);
set(nz,'XData',pn(1),'YData',pn(2),'ZData',pn(3));
X(:,end+1) = pos; if size(X,2) > 400, X = X(:,2:end); end
set(tr,'XData',X(1,:),'YData',X(2,:),'ZData',X(3,:));
axis(ax,[pos(1)-1.5 pos(1)+1.5 pos(2)-1.5 pos(2)+1.5 0 max(2,pos(3)+1)]);
title(ax,sprintf('KE88 en vivo  |  altura z = %.2f m',pos(3)));
drawnow limitrate
end
